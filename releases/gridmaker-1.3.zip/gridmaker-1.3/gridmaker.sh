java -jar GridMaker.jar -i test/test_grid_area.geojson
